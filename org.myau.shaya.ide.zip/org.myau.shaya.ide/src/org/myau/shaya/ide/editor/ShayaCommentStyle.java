package org.myau.shaya.ide.editor;

/** Dialect-specific comment style for Toggle Comment (extension -> dialect law). */
public enum ShayaCommentStyle {
	/** // line comments (Copilot, Grok.3, Claude, Vetka_A/C, …) */
	LINE_SLASH,
	/** | line comments (Gemini / classic Kushnirenko textbooks) */
	LINE_PIPE,
	/** (* … *) block comments (Vetka_B) */
	BLOCK_PAREN;

	public static ShayaCommentStyle forDialect(ShayaKeywords.Dialect dialect) {
		if (dialect == null) {
			return LINE_SLASH;
		}
		switch (dialect) {
		case GEMINI:
		case MAINLAST:
			return LINE_PIPE;
		case VETKA_B:
			return BLOCK_PAREN;
		default:
			return LINE_SLASH;
		}
	}
}
