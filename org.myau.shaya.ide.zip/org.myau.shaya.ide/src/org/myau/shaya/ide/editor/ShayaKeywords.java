package org.myau.shaya.ide.editor;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import org.myau.shaya.ide.toolchain.ShayaToolchain;

/**
 * Per-engine Russian keyword lists for syntax highlighting / status line.
 * Each SHAYA dialect is its own interpreter with its own grammar — keywords are
 * NOT a single shared "guess by text" list, they are keyed by {@link Dialect}
 * (which itself is derived only from the file extension, same law as
 * {@link ShayaToolchain#engineIdFor(java.io.File)}).
 *
 * <p>Sources: Copilot textmate/shaya.tmLanguage.json, Grok.3 ShayaInterpreter.Lexer.KEYWORDS,
 * Gemini lang_tokens._RU_KEYWORDS, Claude ClaudeRyap.py Lexer.KEYWORDS, Ветка_A/B/C lexer.py
 * KEYWORDS dicts.</p>
 */
public final class ShayaKeywords {

	private ShayaKeywords() {
	}

	public enum Dialect {
		COPILOT, GROK1, GROK2, GROK3, GEMINI, CLAUDE, MAINLAST, VETKA_A, VETKA_B, VETKA_C, GENERIC
	}

	/** Copilot (.шая / .copilot.shaya) — начало/кон, все, кпр, конмод, ... */
	public static final String[] COPILOT = {
			"алг", "начало", "кон", "если", "иначе", "все", "пока", "для", "от", "до", "шаг",
			"кц", "проц", "кпр", "вызов", "вернуть", "попробуй", "ошибка", "включить", "модуль",
			"конмод", "экспорт", "использовать", "тип", "конст"
	};
	public static final String[] COPILOT_TYPES = { "цел", "реал", "стр", "лог", "истина", "ложь" };
	public static final String[] COPILOT_IO = {
			"ввод", "вывод", "открыть", "закрыть", "считать", "считать_слово", "считать_файл",
			"записать", "как", "режим", "из", "в"
	};

	/** Grok.3 (.shaya) — нач/кон, кесли/кпока/кдля/кфун, попытка/исключение. */
	public static final String[] GROK3 = {
			"алг", "нач", "кон", "если", "то", "иначе", "кесли", "пока", "делай", "кпока",
			"для", "от", "до", "кдля", "функ", "кфун", "возврат", "использовать", "попытка",
			"исключение", "кпопытка", "вызвать", "как"
	};
	public static final String[] GROK3_TYPES = { "цел", "вещ", "лит", "лог", "мас", "словарь", "множ", "символ", "файл" };
	public static final String[] GROK3_IO = { "ввод", "вывод", "фввод", "фвывод", "открыть", "закрыть" };

	/** Gemini (.alg) — classic Kushnirenko (нач/кон, все, нц/кц, рез/арг). */
	public static final String[] GEMINI = {
			"алг", "арг", "нач", "кон", "конст", "ввод", "вывод", "если", "то", "иначе", "все",
			"нц", "пока", "для", "от", "до", "кц", "рез", "использовать"
	};
	public static final String[] GEMINI_TYPES = {
			"цел", "вещ", "лог", "лит", "таб", "файл", "запись", "переч", "словарь"
	};
	public static final String[] GEMINI_LITERALS = { "да", "нет", "и", "или", "не" };

	/** Claude (.shal) — same нач/кон/кесли family as Grok.3, plus modules. */
	public static final String[] CLAUDE = {
			"алг", "нач", "кон", "если", "то", "иначе", "кесли", "пока", "делай", "кпока",
			"для", "от", "до", "кдля", "вывод", "ввод", "функ", "кфун", "возврат",
			"использовать", "попытка", "исключение", "кпопытка", "вызвать", "как"
	};
	public static final String[] CLAUDE_LITERALS = { "истина", "ложь", "и", "или", "не" };

	/** mainLAST (.mlast / .shay) — approximated on the classic Kushnirenko core (.alg examples). */
	public static final String[] MAINLAST = GEMINI;
	public static final String[] MAINLAST_TYPES = GEMINI_TYPES;

	/** Ветка_A (.sha). */
	public static final String[] VETKA_A = {
			"алг", "нач", "кон", "если", "то", "иначе", "пока", "делать", "вывод", "ввод",
			"проц", "функ", "возврат", "для", "каждого", "попробовать"
	};
	public static final String[] VETKA_A_TYPES = { "цел", "вещ", "лог", "сим", "стр", "лит" };
	public static final String[] VETKA_A_LITERALS = { "и", "или", "не" };

	/** Ветка_B / Qwen (.shb) — richer builtin set (open/read/write, dано/надо). */
	public static final String[] VETKA_B = {
			"алг", "нач", "кон", "если", "то", "иначе", "пока", "делать", "делай", "для", "от",
			"до", "шаг", "вывод", "ввод", "проц", "функ", "возврат", "таб", "цикл", "кон_цикл",
			"открыть", "читать", "писать", "прервать", "продолжить", "вызов", "при", "все",
			"дано", "надо", "нц", "кц", "раз", "выбор", "арг", "рез", "аргрез"
	};
	public static final String[] VETKA_B_TYPES = { "цел", "вещ", "лог", "сим", "лит" };
	public static final String[] VETKA_B_LITERALS = { "истина", "ложь", "и", "или", "не", "да", "нет" };

	/** Ветка_C / DeepSeek (.shc) — close to Ветка_A with арг/рез/аргрез and раз. */
	public static final String[] VETKA_C = {
			"алг", "нач", "кон", "если", "то", "иначе", "пока", "делать", "вывод", "ввод",
			"проц", "функ", "возврат", "арг", "рез", "аргрез", "раз"
	};
	public static final String[] VETKA_C_TYPES = { "цел", "вещ", "лог", "сим", "лит", "таб" };
	public static final String[] VETKA_C_LITERALS = { "и", "или" };

	public static Dialect dialectOfFileName(String name) {
		String engine = ShayaToolchain.engineIdForName(name);
		if (engine == null) {
			return Dialect.GENERIC;
		}
		switch (engine) {
		case ShayaToolchain.ENGINE_COPILOT:
			return Dialect.COPILOT;
		case ShayaToolchain.ENGINE_GROK1:
			return Dialect.GROK1;
		case ShayaToolchain.ENGINE_GROK2:
			return Dialect.GROK2;
		case ShayaToolchain.ENGINE_GROK3:
			return Dialect.GROK3;
		case ShayaToolchain.ENGINE_GEMINI:
			return Dialect.GEMINI;
		case ShayaToolchain.ENGINE_CLAUDE:
			return Dialect.CLAUDE;
		case ShayaToolchain.ENGINE_MAINLAST:
			return Dialect.MAINLAST;
		case ShayaToolchain.ENGINE_VETKA_A:
			return Dialect.VETKA_A;
		case ShayaToolchain.ENGINE_VETKA_B:
			return Dialect.VETKA_B;
		case ShayaToolchain.ENGINE_VETKA_C:
			return Dialect.VETKA_C;
		default:
			return Dialect.GENERIC;
		}
	}

	/** Control keywords for the given dialect (highlighter). */
	public static String[] controlFor(Dialect dialect) {
		switch (dialect) {
		case COPILOT:
			return COPILOT;
		case GROK1:
		case GROK2:
		case GROK3:
			return GROK3;
		case GEMINI:
			return GEMINI;
		case CLAUDE:
			return CLAUDE;
		case MAINLAST:
			return MAINLAST;
		case VETKA_A:
			return VETKA_A;
		case VETKA_B:
			return VETKA_B;
		case VETKA_C:
			return VETKA_C;
		default:
			return GEMINI;
		}
	}

	/** Type keywords for the given dialect (highlighter). */
	public static String[] typesFor(Dialect dialect) {
		switch (dialect) {
		case COPILOT:
			return COPILOT_TYPES;
		case GROK1:
		case GROK2:
		case GROK3:
			return GROK3_TYPES;
		case GEMINI:
			return GEMINI_TYPES;
		case MAINLAST:
			return MAINLAST_TYPES;
		case VETKA_A:
			return VETKA_A_TYPES;
		case VETKA_B:
			return VETKA_B_TYPES;
		case VETKA_C:
			return VETKA_C_TYPES;
		case CLAUDE:
		default:
			return GEMINI_TYPES;
		}
	}

	/** Builtin / literal / io keywords for the given dialect (highlighter). */
	public static String[] builtinsFor(Dialect dialect) {
		switch (dialect) {
		case COPILOT:
			return COPILOT_IO;
		case GROK1:
		case GROK2:
		case GROK3:
			return GROK3_IO;
		case GEMINI:
			return GEMINI_LITERALS;
		case CLAUDE:
			return CLAUDE_LITERALS;
		case VETKA_A:
			return VETKA_A_LITERALS;
		case VETKA_B:
			return VETKA_B_LITERALS;
		case VETKA_C:
			return VETKA_C_LITERALS;
		default:
			return GEMINI_LITERALS;
		}
	}

	/** All proposals (control + types + builtins), unique + sorted, for the given dialect. */
	public static String[] proposalsFor(Dialect dialect) {
		List<String[]> groups = new ArrayList<>();
		groups.add(controlFor(dialect));
		groups.add(typesFor(dialect));
		groups.add(builtinsFor(dialect));
		int n = 0;
		for (String[] g : groups) {
			n += g.length;
		}
		String[] all = new String[n];
		int i = 0;
		for (String[] g : groups) {
			System.arraycopy(g, 0, all, i, g.length);
			i += g.length;
		}
		return uniqueSorted(all);
	}

	public static boolean isKeyword(String word, Dialect dialect) {
		if (word == null || word.isEmpty()) {
			return false;
		}
		String lower = word.toLowerCase(Locale.ROOT);
		return containsIgnoreCase(controlFor(dialect), lower) || containsIgnoreCase(typesFor(dialect), lower)
				|| containsIgnoreCase(builtinsFor(dialect), lower);
	}

	private static boolean containsIgnoreCase(String[] words, String lower) {
		for (String w : words) {
			if (w != null && w.toLowerCase(Locale.ROOT).equals(lower)) {
				return true;
			}
		}
		return false;
	}

	private static String[] uniqueSorted(String[] raw) {
		Set<String> set = new LinkedHashSet<>();
		for (String s : raw) {
			if (s != null && !s.isEmpty()) {
				set.add(s);
			}
		}
		String[] arr = set.toArray(new String[0]);
		Arrays.sort(arr, Comparator.naturalOrder());
		return arr;
	}
}
