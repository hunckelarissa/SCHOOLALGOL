package org.myau.shaya.ide.editor;

/**
 * Insertable skeletons for Ctrl+Space — per extension dialect (not one shared guess).
 * Cursor marked with {@code §}.
 */
public final class ShayaTemplates {

	private static final char CURSOR = '§';

	public static final class Template {
		public final String label;
		public final String body;
		public final int cursor;

		public Template(String label, String body, int cursor) {
			this.label = label;
			this.body = body;
			this.cursor = cursor;
		}
	}

	private ShayaTemplates() {
	}

	public static Template[] forDialect(ShayaKeywords.Dialect dialect) {
		if (dialect == null) {
			dialect = ShayaKeywords.Dialect.GENERIC;
		}
		switch (dialect) {
		case COPILOT:
			return copilot();
		case GROK1:
			return grok1();
		case GROK2:
			return grok2();
		case GROK3:
			return grok3();
		case CLAUDE:
			return claude();
		case GEMINI:
			return gemini();
		case MAINLAST:
			return mainLast();
		case VETKA_B:
			return vetkaB();
		case VETKA_A:
		case VETKA_C:
			return vetkaAC();
		default:
			return gemini();
		}
	}

	private static Template[] copilot() {
		return new Template[] {
				tpl("алг…", "алг начало\n§\nкон\n"),
				tpl("если…", "если §\n  \nвсе\n"),
				tpl("если-иначе…", "если §\n  \nиначе\n  \nвсе\n"),
				tpl("пока…", "пока §\n  \nкц\n"),
				tpl("для…", "для i от 1 до 10\n  §\nкц\n"),
				tpl("проц…", "проц Имя\n§\nкпр\n"),
				tpl("вывод…", "вывод \"§\"\n")
		};
	}

	private static Template[] grok1() {
		return new Template[] {
				tpl("нач…", "нач\n  §\nкон\n"),
				tpl("если…", "если § то\n    \nкесли\n"),
				tpl("если-иначе…", "если § то\n    \nиначе\n    \nкесли\n"),
				tpl("пока…", "пока § делай\n    \nкпока\n"),
				tpl("для…", "для i от 1 до 10\n    §\nкдля\n"),
				tpl("вывод…", "вывод \"§\"\n")
		};
	}

	private static Template[] grok2() {
		return new Template[] {
				tpl("алг…", "алг Главная\nнач\n    §\nкон\n"),
				tpl("если…", "если § то\n    \nкесли\n"),
				tpl("если-иначе…", "если § то\n    \nиначе\n    \nкесли\n"),
				tpl("пока…", "пока § делай\n    \nкпока\n"),
				tpl("для…", "для i от 1 до 10\n    §\nкдля\n"),
				tpl("вывод…", "вывод \"§\"\n")
		};
	}

	private static Template[] grok3() {
		return new Template[] {
				tpl("алг…", "алг main\nнач\n    §\nкон\n\nmain\n"),
				tpl("если…", "если § то\n    \nкесли\n"),
				tpl("если-иначе…", "если § то\n    \nиначе\n    \nкесли\n"),
				tpl("пока…", "пока § делай\n    \nкпока\n"),
				tpl("для…", "для i от 1 до 10\n    §\nкдля\n"),
				tpl("функ…", "алг имя() -> цел\nнач\n    возврат §0\nкон\n"),
				tpl("вывод…", "вывод \"§\"\n")
		};
	}

	private static Template[] claude() {
		return new Template[] {
				tpl("алг…", "алг Имя\nнач\n    §\nкон\n"),
				tpl("если…", "если § то\n    \nкесли\n"),
				tpl("если-иначе…", "если § то\n    \nиначе\n    \nкесли\n"),
				tpl("пока…", "пока § делай\n    \nкпока\n"),
				tpl("для…", "для i от 1 до 10 делай\n    §\nкдля\n"),
				tpl("вывод…", "вывод \"§\"\n")
		};
	}

	private static Template[] gemini() {
		return new Template[] {
				tpl("алг…", "алг основнаяпрограмма\nнач\n  §\nкон\n"),
				tpl("если…", "если § то\n  \nвсе\n"),
				tpl("если-иначе…", "если § то\n  \nиначе\n  \nвсе\n"),
				tpl("нц-пока…", "нц пока §\n  \nкц\n"),
				tpl("нц-для…", "нц для i от 1 до 10\n  §\nкц\n"),
				tpl("вывод…", "вывод \"§\"\n")
		};
	}

	private static Template[] mainLast() {
		return new Template[] {
				tpl("АЛГ…", "АЛГ\nНАЧ\n  §\nКОН\n"),
				tpl("если…", "ЕСЛИ § ТО\n  \nВСЕ\n"),
				tpl("если-иначе…", "ЕСЛИ § ТО\n  \nИНАЧЕ\n  \nВСЕ\n"),
				tpl("нц-пока…", "НЦ ПОКА §\n  \nКЦ\n"),
				tpl("ВЫВОД…", "ВЫВОД \"§\"\n")
		};
	}

	private static Template[] vetkaAC() {
		return new Template[] {
				tpl("алг…", "алг привет;\nнач\n  §\nкон\n"),
				tpl("если…", "если § то\n  \nвсе;\n"),
				tpl("если-иначе…", "если § то\n  \nиначе\n  \nвсе;\n"),
				tpl("пока…", "пока § делать\n  \nкон\n"),
				tpl("для…", "для i от 1 до 10 делать\n  §\nкон\n"),
				tpl("вывод…", "вывод \"§\";\n")
		};
	}

	private static Template[] vetkaB() {
		return new Template[] {
				tpl("алг…", "алг Привет\nнач\n  §\nкон\n"),
				tpl("если…", "если § то\n  \nкон\n"),
				tpl("если-иначе…", "если § то\n  \nиначе\n  \nкон\n"),
				tpl("пока…", "пока § делай\n  \nкон\n"),
				tpl("для…", "для i от 1 до 10 шаг 1 делать\n  §\nкон\n"),
				tpl("вывод…", "вывод(\"§\")\n")
		};
	}

	private static Template tpl(String label, String raw) {
		int c = raw.indexOf(CURSOR);
		String body = raw.replace(String.valueOf(CURSOR), "");
		if (c < 0) {
			c = body.length();
		}
		return new Template(label, body, Math.min(c, body.length()));
	}
}
