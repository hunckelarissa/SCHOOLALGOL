package org.myau.shaya.ide.content;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;

import org.eclipse.core.runtime.QualifiedName;
import org.eclipse.core.runtime.content.IContentDescription;
import org.eclipse.core.runtime.content.ITextContentDescriber;

/**
 * No-op describer kept for binary compatibility. Content type selection is
 * extension / file-pattern only ({@code plugin.xml}); this never inspects bytes.
 */
public class ShayaGrokContentDescriber implements ITextContentDescriber {

	@Override
	public int describe(Reader contents, IContentDescription description) throws IOException {
		return VALID;
	}

	@Override
	public int describe(InputStream contents, IContentDescription description) throws IOException {
		return VALID;
	}

	@Override
	public QualifiedName[] getSupportedOptions() {
		return new QualifiedName[0];
	}
}
