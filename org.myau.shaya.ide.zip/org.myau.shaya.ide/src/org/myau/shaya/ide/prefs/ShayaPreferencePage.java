package org.myau.shaya.ide.prefs;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.preference.BooleanFieldEditor;
import org.eclipse.jface.preference.DirectoryFieldEditor;
import org.eclipse.jface.preference.FieldEditorPreferencePage;
import org.eclipse.jface.preference.FileFieldEditor;
import org.eclipse.jface.preference.IntegerFieldEditor;
import org.eclipse.jface.preference.StringFieldEditor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;
import org.myau.shaya.ide.Activator;
import org.myau.shaya.ide.run.ShayaLastLaunch;
import org.myau.shaya.ide.toolchain.ShayaToolchain;

/**
 * Preferences → SHAYA
 */
public class ShayaPreferencePage extends FieldEditorPreferencePage implements IWorkbenchPreferencePage {

	public ShayaPreferencePage() {
		super(GRID);
		setPreferenceStore(Activator.getDefault().getPreferenceStore());
		setDescription(
				"Myau SHAYA IDE — Школьный Алгоритмический Язык.\n"
						+ "Проект посвящён памяти кота Семёна.\n\n"
						+ "Toolchain home empty = auto-detect dropins/myau-shaya-plugin.\n"
						+ "Engine = file extension only (SHAYA → EXTENSION_MAP…).\n"
						+ "Extra args → tools/shaya-run.bat · Python empty = PATH / py -3.\n"
						+ "Check on save: Copilot (.шая) and Vetka_B (.shb) only.");
	}

	@Override
	public void init(IWorkbench workbench) {
	}

	@Override
	protected void createFieldEditors() {
		addField(new DirectoryFieldEditor(
				ShayaPreferenceConstants.TOOLCHAIN_HOME,
				"Toolchain home (myau-shaya-plugin):",
				getFieldEditorParent()));
		addField(new StringFieldEditor(
				ShayaPreferenceConstants.EXTRA_ARGS,
				"Extra args:",
				getFieldEditorParent()));
		addField(new FileFieldEditor(
				ShayaPreferenceConstants.PYTHON_EXECUTABLE,
				"Python (empty = PATH / py -3):",
				getFieldEditorParent()));
		IntegerFieldEditor indent = new IntegerFieldEditor(
				ShayaPreferenceConstants.INDENT_WIDTH,
				"Indent width (spaces, 2 or 4):",
				getFieldEditorParent());
		indent.setValidRange(2, 4);
		addField(indent);
		addField(new BooleanFieldEditor(
				ShayaPreferenceConstants.INSERT_SPACES,
				"Insert spaces for tabs (off = real tab character)",
				getFieldEditorParent()));
		addField(new BooleanFieldEditor(
				ShayaPreferenceConstants.CHECK_ON_SAVE,
				"Check on save (Copilot / Vetka_B only)",
				getFieldEditorParent()));
	}

	@Override
	protected void contributeButtons(Composite parent) {
		super.contributeButtons(parent);
		((GridLayout) parent.getLayout()).numColumns += 2;

		Button validate = new Button(parent, SWT.PUSH);
		validate.setText("Validate…");
		validate.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false));
		validate.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				performApply();
				String status = ShayaToolchain.validateStatus();
				boolean ok = !status.contains("FAIL");
				if (ok) {
					MessageDialog.openInformation(getShell(), "SHAYA Validate", status);
				} else {
					MessageDialog.openWarning(getShell(), "SHAYA Validate", status);
				}
			}
		});

		Button clear = new Button(parent, SWT.PUSH);
		clear.setText("Clear Recent");
		clear.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false));
		clear.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				ShayaLastLaunch.clearHistory();
				MessageDialog.openInformation(getShell(), "SHAYA",
						"Recent / Run Last history cleared.");
			}
		});
	}
}
