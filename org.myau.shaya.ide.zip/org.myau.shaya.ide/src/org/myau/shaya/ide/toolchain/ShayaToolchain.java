package org.myau.shaya.ide.toolchain;

import java.io.File;
import java.net.URI;
import java.net.URL;
import java.util.Locale;

import org.eclipse.core.runtime.FileLocator;
import org.eclipse.core.runtime.Platform;
import org.eclipse.jface.preference.IPreferenceStore;
import org.myau.shaya.ide.Activator;
import org.myau.shaya.ide.prefs.ShayaPreferenceConstants;
import org.osgi.framework.Bundle;

/**
 * Locates the self-contained myau-shaya-plugin dropins folder and the run wrapper.
 * Engine is chosen strictly by file extension (no heuristics, no guessing by content).
 *
 * <p>Official extension -&gt; engine law (product map, MVP):</p>
 * <pre>
 *   .шая / .copilot.shaya -&gt; copilot
 *   .shaya1               -&gt; grok1
 *   .shaya2               -&gt; grok2
 *   .shaya                -&gt; grok3     (compound ".copilot.shaya" is checked FIRST)
 *   .alg                  -&gt; gemini
 *   .shal                 -&gt; claude
 *   .mlast / .shay        -&gt; mainLAST
 *   .sha                  -&gt; vetka_a
 *   .shb                  -&gt; vetka_b
 *   .shc                  -&gt; vetka_c
 * </pre>
 */
public final class ShayaToolchain {

	/** Engine ids returned by {@link #engineIdFor(File)} — stable, used by wrapper + prefs. */
	public static final String ENGINE_COPILOT = "copilot";
	public static final String ENGINE_GROK1 = "grok1";
	public static final String ENGINE_GROK2 = "grok2";
	public static final String ENGINE_GROK3 = "grok3";
	public static final String ENGINE_GEMINI = "gemini";
	public static final String ENGINE_CLAUDE = "claude";
	public static final String ENGINE_MAINLAST = "mainLAST";
	public static final String ENGINE_VETKA_A = "vetka_a";
	public static final String ENGINE_VETKA_B = "vetka_b";
	public static final String ENGINE_VETKA_C = "vetka_c";

	private ShayaToolchain() {
	}

	public static File getToolchainHome() {
		IPreferenceStore prefs = Activator.getDefault().getPreferenceStore();
		String configured = prefs.getString(ShayaPreferenceConstants.TOOLCHAIN_HOME);
		if (configured != null && !configured.isBlank()) {
			File f = new File(configured.trim());
			if (f.isDirectory()) {
				return f;
			}
		}

		File fromBundle = locateBesideBundle();
		if (fromBundle != null) {
			return fromBundle;
		}

		try {
			URL install = Platform.getInstallLocation().getURL();
			File home = new File(install.toURI());
			File dropin = new File(home, "dropins" + File.separator + "myau-shaya-plugin");
			if (dropin.isDirectory()) {
				return dropin;
			}
		} catch (Exception ignored) {
		}

		return null;
	}

	private static File locateBesideBundle() {
		try {
			Bundle bundle = Platform.getBundle(Activator.PLUGIN_ID);
			if (bundle == null) {
				return null;
			}
			URL entry = bundle.getEntry("/");
			if (entry == null) {
				return null;
			}
			URL fileUrl = FileLocator.toFileURL(entry);
			File dir = new File(fileUrl.getPath());
			if (!dir.exists()) {
				dir = new File(URI.create(fileUrl.toString()));
			}
			if (dir.isFile()) {
				dir = dir.getParentFile();
			}
			if (dir == null) {
				return null;
			}
			if (looksLikeToolchain(dir)) {
				return dir;
			}
			File parent = dir.getParentFile();
			if (parent != null && looksLikeToolchain(parent)) {
				return parent;
			}
			// dropins/myau-shaya-plugin sibling of dropins/<bundle-jar-or-dir>
			if (parent != null) {
				File sibling = new File(parent, "myau-shaya-plugin");
				if (looksLikeToolchain(sibling)) {
					return sibling;
				}
			}
			return dir;
		} catch (Exception e) {
			return null;
		}
	}

	private static boolean looksLikeToolchain(File dir) {
		return new File(dir, "tools").isDirectory() || new File(dir, "interpreters").isDirectory();
	}

	/** tools/shaya-run.bat inside the toolchain home. */
	public static File getRunWrapper() {
		File home = getToolchainHome();
		if (home == null) {
			return null;
		}
		File bat = new File(home, "tools" + File.separator + "shaya-run.bat");
		return bat.isFile() ? bat : null;
	}

	/**
	 * Hard extension map — see class javadoc. Compound ".copilot.shaya" is matched
	 * BEFORE the plain ".shaya" suffix so the Copilot alias never resolves to Grok.3.
	 *
	 * @return engine id, or {@code null} if the extension is not in the SHAYA map
	 */
	public static String engineIdFor(File source) {
		if (source == null) {
			return null;
		}
		return engineIdForName(source.getName());
	}

	public static String engineIdForName(String fileName) {
		if (fileName == null) {
			return null;
		}
		String name = fileName.toLowerCase(Locale.ROOT);
		if (name.endsWith(".copilot.shaya")) {
			return ENGINE_COPILOT;
		}
		if (name.endsWith(".шая")) {
			return ENGINE_COPILOT;
		}
		if (name.endsWith(".shaya1")) {
			return ENGINE_GROK1;
		}
		if (name.endsWith(".shaya2")) {
			return ENGINE_GROK2;
		}
		if (name.endsWith(".shaya")) {
			return ENGINE_GROK3;
		}
		if (name.endsWith(".alg")) {
			return ENGINE_GEMINI;
		}
		if (name.endsWith(".shal")) {
			return ENGINE_CLAUDE;
		}
		if (name.endsWith(".mlast") || name.endsWith(".shay")) {
			return ENGINE_MAINLAST;
		}
		if (name.endsWith(".sha")) {
			return ENGINE_VETKA_A;
		}
		if (name.endsWith(".shb")) {
			return ENGINE_VETKA_B;
		}
		if (name.endsWith(".shc")) {
			return ENGINE_VETKA_C;
		}
		return null;
	}

	public static boolean isShayaSource(String fileName) {
		return engineIdForName(fileName) != null;
	}

	/** Short list for dialogs / warnings (keep in sync with the extension map). */
	public static String extensionsHint() {
		return ".шая .copilot.shaya .shaya1 .shaya2 .shaya .alg .shal .mlast .shay .sha .shb .shc";
	}

	/** One-line engine map for console / refuse messages. */
	public static String enginesHint() {
		return "шая/copilot.shaya→Copilot | shaya1→Grok.1 | shaya2→Grok.2 | shaya→Grok.3 | "
				+ "alg→Gemini | shal→Claude | mlast/shay→mainLAST | sha/shb/shc→Ветки";
	}

	/** Human-readable engine label for status line / console / About. */
	public static String engineDisplayName(String engineId) {
		if (engineId == null) {
			return "unknown";
		}
		switch (engineId) {
		case ENGINE_COPILOT:
			return "Copilot";
		case ENGINE_GROK1:
			return "Grok.1";
		case ENGINE_GROK2:
			return "Grok.2";
		case ENGINE_GROK3:
			return "Grok.3";
		case ENGINE_GEMINI:
			return "Gemini";
		case ENGINE_CLAUDE:
			return "Claude";
		case ENGINE_MAINLAST:
			return "mainLAST (ChatGPT)";
		case ENGINE_VETKA_A:
			return "Ветка_A";
		case ENGINE_VETKA_B:
			return "Ветка_B (Qwen)";
		case ENGINE_VETKA_C:
			return "Ветка_C (DeepSeek)";
		default:
			return engineId;
		}
	}

	/**
	 * Engines with a usable CLI check mode for MVP:
	 * Copilot {@code --check}, Vetka_B {@code --no-exec}.
	 */
	public static boolean supportsCheck(String engineId) {
		return ENGINE_COPILOT.equals(engineId) || ENGINE_VETKA_B.equals(engineId);
	}

	/**
	 * Engines with a usable CLI debug/trace mode (console {@code --debug}/{@code --trace},
	 * not Eclipse step-debug UI — see docs/TODO_DEBUG_LIKE_JAVA.md).
	 */
	public static boolean supportsDebug(String engineId) {
		return ENGINE_COPILOT.equals(engineId) || ENGINE_GROK2.equals(engineId)
				|| ENGINE_GROK3.equals(engineId)
				|| ENGINE_GEMINI.equals(engineId) || ENGINE_CLAUDE.equals(engineId)
				|| ENGINE_MAINLAST.equals(engineId)
				|| ENGINE_VETKA_A.equals(engineId) || ENGINE_VETKA_C.equals(engineId)
				|| ENGINE_VETKA_B.equals(engineId) || ENGINE_GROK1.equals(engineId);
	}

	/**
	 * Eclipse step-debug UI (gutter BP / Variables) via one wire protocol {@code SHAYDBG}.
	 * CLI Debug ({@link #supportsDebug}) stays available separately.
	 */
	public static boolean supportsStepDebugUi(String engineId) {
		return ENGINE_COPILOT.equals(engineId) || ENGINE_MAINLAST.equals(engineId)
				|| ENGINE_GROK3.equals(engineId) || ENGINE_GROK2.equals(engineId)
				|| ENGINE_CLAUDE.equals(engineId) || ENGINE_GEMINI.equals(engineId)
				|| ENGINE_GROK1.equals(engineId) || ENGINE_VETKA_A.equals(engineId)
				|| ENGINE_VETKA_C.equals(engineId) || ENGINE_VETKA_B.equals(engineId);
	}

	public static String debugRefuseMessage(String engineId) {
		String name = engineDisplayName(engineId);
		return name + " — CLI Debug is not available for this engine.";
	}

	public static String stepDebugRefuseMessage(String engineId) {
		String name = engineDisplayName(engineId);
		if (supportsStepDebugUi(engineId)) {
			return name + " — step-debug is available (Debug As / SHAYA → Step Debug).";
		}
		return name + " — Eclipse step-debug (SHAYDBG) is not available yet.\n"
				+ "Use SHAYA → Debug for CLI debug/trace when supported, or Run.\n"
				+ "One protocol; all engines with SHAYDBG use the same wire.";
	}

	/**
	 * Working directory for an engine (dropins interpreters/… or repo vendor folder).
	 */
	public static File getEngineWorkDir(String engineId) {
		String dirName = engineDirName(engineId);
		if (dirName == null) {
			return null;
		}
		File home = getToolchainHome();
		if (home != null) {
			File underInterp = new File(home, "interpreters" + File.separator + dirName);
			if (underInterp.isDirectory()) {
				return underInterp;
			}
			File underHome = new File(home, dirName);
			if (underHome.isDirectory()) {
				return underHome;
			}
		}
		return null;
	}

	/** Entry script for engines that use {@code python <script>} (not {@code -m}). */
	public static File getEngineEntryScript(String engineId) {
		File cwd = getEngineWorkDir(engineId);
		if (cwd == null) {
			return null;
		}
		String entry = engineEntryScriptName(engineId);
		if (entry == null) {
			return null;
		}
		File script = new File(cwd, entry);
		return script.isFile() ? script : null;
	}

	private static String engineDirName(String engineId) {
		if (engineId == null) {
			return null;
		}
		switch (engineId) {
		case ENGINE_COPILOT:
			return "Copilot";
		case ENGINE_GROK1:
			return "Grok.1";
		case ENGINE_GROK2:
			return "Grok.2";
		case ENGINE_GROK3:
			return "Grok.3";
		case ENGINE_GEMINI:
			return "Gemini";
		case ENGINE_CLAUDE:
			return "Claude";
		case ENGINE_MAINLAST:
			return "mainLAST (ChatGPT)";
		case ENGINE_VETKA_A:
			return "Ветка_A";
		case ENGINE_VETKA_B:
			return "Ветка_B (Qwen)";
		case ENGINE_VETKA_C:
			return "Ветка_C (DeepSeek)";
		default:
			return null;
		}
	}

	private static String engineEntryScriptName(String engineId) {
		if (ENGINE_COPILOT.equals(engineId)) {
			return "интерпретатор.py";
		}
		if (ENGINE_GROK1.equals(engineId)) {
			return "shaya.py";
		}
		if (ENGINE_GROK2.equals(engineId)) {
			return "GrokRyapLAST.py";
		}
		if (ENGINE_GROK3.equals(engineId)) {
			return "run_shaya.py";
		}
		if (ENGINE_GEMINI.equals(engineId)) {
			return "main.py";
		}
		if (ENGINE_CLAUDE.equals(engineId)) {
			return "ClaudeRyap.py";
		}
		if (ENGINE_MAINLAST.equals(engineId)) {
			return "mainLAST.py";
		}
		if (ENGINE_VETKA_A.equals(engineId)) {
			return "main.py";
		}
		if (ENGINE_VETKA_B.equals(engineId)) {
			return "shal_interpreter27.py";
		}
		return null;
	}

	/**
	 * Preference-page smoke check: home, wrapper, interpreters, Python.
	 * Returns a multi-line human status (never null).
	 */
	public static String validateStatus() {
		StringBuilder sb = new StringBuilder();
		boolean ok = true;

		File home = getToolchainHome();
		if (home == null || !home.isDirectory()) {
			sb.append("FAIL  Toolchain home not found\n");
			sb.append("      Set Preferences → SHAYA → Toolchain home\n");
			sb.append("      or install dropins/myau-shaya-plugin/\n");
			ok = false;
		} else {
			sb.append("OK    Toolchain home: ").append(home.getAbsolutePath()).append('\n');
		}

		File wrap = getRunWrapper();
		if (wrap == null || !wrap.isFile()) {
			sb.append("FAIL  tools/shaya-run.bat missing\n");
			ok = false;
		} else {
			sb.append("OK    Wrapper: ").append(wrap.getAbsolutePath()).append('\n');
		}

		if (home != null) {
			File interp = new File(home, "interpreters");
			if (!interp.isDirectory()) {
				sb.append("FAIL  interpreters/ missing under toolchain home\n");
				ok = false;
			} else {
				String[] need = {
						"Copilot",
						"Grok.1",
						"Grok.2",
						"Grok.3",
						"Gemini",
						"Claude",
						"mainLAST (ChatGPT)",
						"Ветка_A",
						"Ветка_B (Qwen)",
						"Ветка_C (DeepSeek)"
				};
				int present = 0;
				StringBuilder missing = new StringBuilder();
				for (String n : need) {
					if (new File(interp, n).isDirectory()) {
						present++;
					} else {
						if (missing.length() > 0) {
							missing.append(", ");
						}
						missing.append(n);
					}
				}
				if (present == need.length) {
					sb.append("OK    Interpreter folders: ").append(present).append('/')
							.append(need.length).append(" (all engines)\n");
				} else if (present == 0) {
					sb.append("FAIL  Interpreter folders: 0/").append(need.length).append('\n');
					ok = false;
				} else {
					sb.append("WARN  Interpreter folders: ").append(present).append('/')
							.append(need.length).append(" — missing: ").append(missing).append('\n');
					// Partial install: still usable for present engines; not a hard FAIL.
				}
			}
		}

		String pyInfo = probePython();
		if (pyInfo.startsWith("OK")) {
			sb.append(pyInfo).append('\n');
		} else {
			sb.append(pyInfo).append('\n');
			ok = false;
		}

		sb.append(ok ? "\nToolchain looks ready." : "\nFix FAIL items, then Validate again.");
		return sb.toString();
	}

	private static String probePython() {
		IPreferenceStore prefs = Activator.getDefault() != null
				? Activator.getDefault().getPreferenceStore() : null;
		String configured = prefs != null ? prefs.getString(ShayaPreferenceConstants.PYTHON_EXECUTABLE) : "";
		if (configured != null && !configured.isBlank()) {
			File f = new File(configured.trim());
			if (f.isFile()) {
				return "OK    Python (prefs): " + f.getAbsolutePath();
			}
			return "FAIL  Python prefs path not a file: " + configured.trim();
		}
		String[] candidates = { "py", "python", "python3" };
		for (String cmd : candidates) {
			try {
				ProcessBuilder pb = cmd.equals("py")
						? new ProcessBuilder("py", "-3", "-c", "import sys; print(sys.executable)")
						: new ProcessBuilder(cmd, "-c", "import sys; print(sys.executable)");
				pb.redirectErrorStream(true);
				Process p = pb.start();
				String out = new String(p.getInputStream().readAllBytes(), java.nio.charset.StandardCharsets.UTF_8)
						.trim();
				int rc = p.waitFor();
				if (rc == 0 && !out.isBlank()) {
					String first = out.lines().findFirst().orElse(out);
					return "OK    Python (PATH/" + cmd + "): " + first;
				}
			} catch (Exception ignored) {
			}
		}
		return "FAIL  Python 3 not found (set Preferences → SHAYA → Python, or PATH / py -3)";
	}
}
