package org.myau.shaya.ide;

import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.IEditorRegistry;
import org.eclipse.ui.IStartup;
import org.eclipse.ui.PlatformUI;

/**
 * Forces default editor associations for SHAYA extensions.
 * plugin.xml alone is not enough when the workspace already cached "Default Text Editor".
 *
 * <p>Eclipse's {@link IEditorRegistry#setDefaultEditor(String, String)} keys associations by
 * the last file extension only, so "*.shaya" and "*.copilot.shaya" cannot both be given a
 * different default editor through this API — both fall under extension "shaya". We register
 * the more common plain ".shaya" (Grok.3) as the default for that bucket; the compound
 * ".copilot.shaya" alias still opens fine (Open With / auto-detected content type), and — more
 * importantly — Run/Check always pick the correct engine because
 * {@link org.myau.shaya.ide.toolchain.ShayaToolchain#engineIdFor(java.io.File)} inspects the
 * full file name and checks the compound suffix first, independent of which editor is shown.</p>
 */
public class ShayaStartup implements IStartup {

	private static final String[][] ASSOC = {
			{ "*.шая", "org.myau.shaya.ide.editor.copilot" },
			{ "*.shaya1", "org.myau.shaya.ide.editor.grok1" },
			{ "*.shaya2", "org.myau.shaya.ide.editor.grok2" },
			{ "*.shaya", "org.myau.shaya.ide.editor.grok3" },
			{ "*.alg", "org.myau.shaya.ide.editor.gemini" },
			{ "*.shal", "org.myau.shaya.ide.editor.claude" },
			{ "*.mlast", "org.myau.shaya.ide.editor.mainlast" },
			{ "*.shay", "org.myau.shaya.ide.editor.mainlast" },
			{ "*.sha", "org.myau.shaya.ide.editor.vetkaA" },
			{ "*.shb", "org.myau.shaya.ide.editor.vetkaB" },
			{ "*.shc", "org.myau.shaya.ide.editor.vetkaC" },
	};

	@Override
	public void earlyStartup() {
		Display.getDefault().asyncExec(() -> {
			if (!PlatformUI.isWorkbenchRunning()) {
				return;
			}
			IEditorRegistry reg = PlatformUI.getWorkbench().getEditorRegistry();
			for (String[] pair : ASSOC) {
				reg.setDefaultEditor(pair[0], pair[1]);
			}
		});
	}
}
