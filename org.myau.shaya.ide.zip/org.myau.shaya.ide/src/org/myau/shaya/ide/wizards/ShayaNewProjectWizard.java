package org.myau.shaya.ide.wizards;

import java.io.ByteArrayInputStream;
import java.lang.reflect.InvocationTargetException;
import java.net.URI;
import java.nio.charset.StandardCharsets;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IProjectDescription;
import org.eclipse.core.resources.IWorkspaceRunnable;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.ui.INewWizard;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.dialogs.WizardNewProjectCreationPage;
import org.eclipse.ui.ide.IDE;
import org.myau.shaya.ide.nature.ShayaNatureSupport;

/**
 * File → New → Project → SHAYA Project (nature + Hello samples for all map extensions).
 */
public class ShayaNewProjectWizard extends Wizard implements INewWizard {

	private IWorkbench workbench;
	private WizardNewProjectCreationPage page;

	@Override
	public void init(IWorkbench workbench, IStructuredSelection selection) {
		this.workbench = workbench;
		setWindowTitle("New SHAYA Project");
		setNeedsProgressMonitor(true);
	}

	@Override
	public void addPages() {
		page = new WizardNewProjectCreationPage("shayaProject");
		page.setTitle("SHAYA Project");
		page.setDescription(
				"Creates a SHAYA project (nature + builder) with Hello samples for every\n"
						+ "official extension (+ .copilot.shaya / .shay aliases).\n"
						+ "Extension → engine law — no dialect guessing.");
		addPage(page);
	}

	@Override
	public boolean performFinish() {
		final IProject project = page.getProjectHandle();
		final URI location = page.getLocationURI();
		try {
			getContainer().run(true, true, monitor -> {
				try {
					ResourcesPlugin.getWorkspace().run((IWorkspaceRunnable) mon -> {
						createProject(project, location, mon);
					}, monitor);
				} catch (CoreException e) {
					throw new InvocationTargetException(e);
				}
			});
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
			page.setErrorMessage("Cancelled.");
			return false;
		} catch (InvocationTargetException e) {
			Throwable cause = e.getCause() != null ? e.getCause() : e;
			String msg = cause.getMessage() != null ? cause.getMessage() : cause.toString();
			page.setErrorMessage(msg);
			if (project.exists()) {
				MessageDialog.openWarning(getShell(), "SHAYA Project",
						"Project was created but setup is incomplete:\n\n" + msg
								+ "\n\nYou can delete the project and try again,"
								+ " or finish Hello samples manually.");
			} else {
				MessageDialog.openError(getShell(), "SHAYA Project", msg);
			}
			return false;
		}

		try {
			IFile open = project.getFile("Hello.shaya");
			if (!open.exists()) {
				open = project.getFile("Hello.alg");
			}
			if (open.exists() && workbench.getActiveWorkbenchWindow() != null) {
				IDE.openEditor(workbench.getActiveWorkbenchWindow().getActivePage(), open);
			}
		} catch (Exception ignored) {
		}
		return true;
	}

	private static void createProject(IProject project, URI location, IProgressMonitor monitor)
			throws CoreException {
		IProjectDescription desc = project.getWorkspace().newProjectDescription(project.getName());
		if (location != null) {
			desc.setLocationURI(location);
		}
		project.create(desc, monitor);
		project.open(monitor);
		ShayaNatureSupport.addNature(project);

		ShayaHelloBodies.Spec[] specs = ShayaHelloBodies.projectDefaults();
		monitor.beginTask("SHAYA samples", specs.length + 1);
		for (ShayaHelloBodies.Spec spec : specs) {
			create(project, "Hello." + spec.ext, spec.body);
			monitor.worked(1);
		}

		create(project, "README-SHAYA.txt", ""
				+ "Myau SHAYA IDE / SEMYON The CAT\n"
				+ "================================\n"
				+ "Проект посвящён памяти кота Семёна.\n"
				+ "\n"
				+ "Extension → engine (product law):\n"
				+ "  .шая / .copilot.shaya → Copilot\n"
				+ "  .shaya1              → Grok.1\n"
				+ "  .shaya2              → Grok.2\n"
				+ "  .shaya               → Grok.3\n"
				+ "  .alg                 → Gemini\n"
				+ "  .shal                → Claude\n"
				+ "  .mlast / .shay       → mainLAST\n"
				+ "  .sha                 → Ветка_A\n"
				+ "  .shb                 → Ветка_B\n"
				+ "  .shc                 → Ветка_C\n"
				+ "\n"
				+ "Open a file → SHAYA → Run / Check / Debug.\n"
				+ "Needs: Python 3 on PATH; for .mlast also: pip install lark\n");
		monitor.worked(1);
		monitor.done();
	}

	private static void create(IProject project, String name, String content) throws CoreException {
		IFile file = project.getFile(name);
		if (!file.exists()) {
			file.create(new ByteArrayInputStream(content.getBytes(StandardCharsets.UTF_8)), true, null);
		}
	}
}
