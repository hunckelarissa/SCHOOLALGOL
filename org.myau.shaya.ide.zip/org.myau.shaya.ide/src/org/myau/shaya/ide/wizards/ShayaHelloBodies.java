package org.myau.shaya.ide.wizards;

/**
 * Hello skeletons for wizards — one body per official product extension.
 * Bodies match examples/&lt;engine&gt;/Hello.* (syntax per engine, not a shared guess).
 */
public final class ShayaHelloBodies {

	public static final class Spec {
		public final String label;
		public final String ext;
		public final String engine;
		public final String body;

		public Spec(String label, String ext, String engine, String body) {
			this.label = label;
			this.ext = ext;
			this.engine = engine;
			this.body = body;
		}

		@Override
		public String toString() {
			return label + "  (*." + ext + " → " + engine + ")";
		}
	}

	private ShayaHelloBodies() {
	}

	public static Spec[] all() {
		return new Spec[] {
				new Spec("Copilot", "шая", "Copilot",
						"алг начало\nвывод \"Hello from Myau SHAYA / Copilot\"\nкон\n"),
				new Spec("Copilot (latin alias)", "copilot.shaya", "Copilot",
						"алг начало\nвывод \"Hello from Myau SHAYA / Copilot\"\nкон\n"),
				new Spec("Grok.1", "shaya1", "Grok.1",
						"нач\n  вывод \"Hello from Myau SHAYA / Grok.1\"\nкон\n"),
				new Spec("Grok.2", "shaya2", "Grok.2",
						"алг Главная\nнач\n    вывод \"Hello from Myau SHAYA / Grok.2\"\nкон\n"),
				new Spec("Grok.3", "shaya", "Grok.3",
						"алг main\nнач\n    вывод \"Hello from Myau SHAYA / Grok.3\"\nкон\n\nmain\n"),
				new Spec("Gemini", "alg", "Gemini",
						"алг основнаяпрограмма\nнач\n  вывод \"Hello from Myau SHAYA / Gemini\"\nкон\n"),
				new Spec("Claude", "shal", "Claude",
						"алг Привет\nнач\n    вывод \"Hello from Myau SHAYA / Claude\"\nкон\n"),
				new Spec("mainLAST", "mlast", "mainLAST",
						"АЛГ\nНАЧ\n  ВЫВОД \"Hello from Myau SHAYA / mainLAST\"\nКОН\n"),
				new Spec("mainLAST (.shay)", "shay", "mainLAST",
						"АЛГ\nНАЧ\n  ВЫВОД \"Hello from Myau SHAYA / mainLAST\"\nКОН\n"),
				new Spec("Ветка_A", "sha", "Ветка_A",
						"алг привет;\nнач\n  вывод \"Hello from Myau SHAYA / Vetka_A\";\n  вывод ;\nкон\n"),
				new Spec("Ветка_B (Qwen)", "shb", "Ветка_B",
						"алг Привет\nнач\n  вывод(\"Hello from Myau SHAYA / Vetka_B\")\nкон\n"),
				new Spec("Ветка_C (DeepSeek)", "shc", "Ветка_C",
						"алг привет;\nнач\n  вывод \"Hello from Myau SHAYA / Vetka_C\";\nкон\n"),
		};
	}

	/** Default set created in a new SHAYA project (all official extensions + aliases). */
	public static Spec[] projectDefaults() {
		return all();
	}
}
