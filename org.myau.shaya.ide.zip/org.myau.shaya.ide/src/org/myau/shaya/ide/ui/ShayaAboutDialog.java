package org.myau.shaya.ide.ui;

import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.myau.shaya.ide.Activator;
import org.myau.shaya.ide.run.ShayaOpenMapHandler;
import org.myau.shaya.ide.toolchain.ShayaDocs;

/**
 * About Myau SHAYA IDE / SEMYON The CAT — portrait + dedication + doc links.
 */
public class ShayaAboutDialog extends Dialog {

	private Image portrait;

	public ShayaAboutDialog(Shell parentShell) {
		super(parentShell);
	}

	@Override
	protected void configureShell(Shell newShell) {
		super.configureShell(newShell);
		newShell.setText("About Myau SHAYA IDE — SEMYON The CAT");
	}

	@Override
	protected Control createDialogArea(Composite parent) {
		Composite area = (Composite) super.createDialogArea(parent);
		area.setLayout(new GridLayout(1, false));

		Label imgLabel = new Label(area, SWT.NONE);
		imgLabel.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, true, false));
		ImageDescriptor desc = Activator.getImageDescriptor("icons/semyon.png");
		if (desc == null) {
			desc = Activator.getImageDescriptor("icons/icon.png");
		}
		if (desc != null) {
			ImageData data = null;
			try {
				data = desc.getImageData(100);
			} catch (Throwable ignored) {
				// older API
			}
			if (data == null) {
				Image tmp = desc.createImage();
				try {
					data = tmp.getImageData();
				} finally {
					tmp.dispose();
				}
			}
			if (data != null) {
				int targetW = 320;
				if (data.width > targetW) {
					int targetH = Math.max(1, (int) (data.height * (targetW / (double) data.width)));
					data = data.scaledTo(targetW, targetH);
				}
				portrait = new Image(parent.getDisplay(), data);
				imgLabel.setImage(portrait);
			}
		}

		Label title = new Label(area, SWT.WRAP | SWT.CENTER);
		title.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false));
		title.setText("Myau SHAYA IDE\nШкольный Алгоритмический Язык — interpreter toolchain for Windows");

		Label dedicate = new Label(area, SWT.WRAP | SWT.CENTER);
		GridData gd = new GridData(SWT.FILL, SWT.CENTER, true, false);
		gd.widthHint = 360;
		gd.verticalIndent = 12;
		dedicate.setLayoutData(gd);
		dedicate.setText("Проект посвящён памяти кота Семёна.");

		Label engines = new Label(area, SWT.WRAP | SWT.CENTER);
		GridData gdEngines = new GridData(SWT.FILL, SWT.CENTER, true, false);
		gdEngines.widthHint = 360;
		gdEngines.verticalIndent = 10;
		engines.setLayoutData(gdEngines);
		engines.setText(
				"шая / copilot.shaya \u2192 Copilot   ·   shaya1 \u2192 Grok.1   ·   shaya2 \u2192 Grok.2\n"
						+ "shaya \u2192 Grok.3   ·   alg \u2192 Gemini   ·   shal \u2192 Claude\n"
						+ "mlast / shay \u2192 mainLAST\n"
						+ "sha \u2192 \u0412\u0435\u0442\u043a\u0430_A   ·   shb \u2192 \u0412\u0435\u0442\u043a\u0430_B (Qwen)   ·   shc \u2192 \u0412\u0435\u0442\u043a\u0430_C (DeepSeek)");

		Label debug = new Label(area, SWT.WRAP | SWT.CENTER);
		GridData gdDebug = new GridData(SWT.FILL, SWT.CENTER, true, false);
		gdDebug.widthHint = 360;
		gdDebug.verticalIndent = 8;
		debug.setLayoutData(gdDebug);
		debug.setText(
				"Debug (CLI) — console --debug/--trace where supported\n"
						+ "Step Debug — Eclipse BP/Variables via SHAYDBG\n"
						+ "(all official extensions)");

		Label meta = new Label(area, SWT.WRAP | SWT.CENTER);
		meta.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false));
		meta.setForeground(parent.getDisplay().getSystemColor(SWT.COLOR_DARK_GRAY));
		meta.setText("Brand: Myau / SEMYON The Cat\nPlugin: " + Activator.PLUGIN_ID
				+ " " + bundleVersion() + "\nToolchain: " + toolchainLine());

		Composite links = new Composite(area, SWT.NONE);
		links.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, true, false));
		links.setLayout(new GridLayout(2, true));
		Button mapBtn = new Button(links, SWT.PUSH);
		mapBtn.setText("EXTENSION_MAP…");
		mapBtn.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				java.io.File map = ShayaDocs.findExtensionMap();
				if (map != null) {
					ShayaOpenMapHandler.openFile(map);
				}
			}
		});
		Button trackBtn = new Button(links, SWT.PUSH);
		trackBtn.setText("Учебный трек…");
		trackBtn.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				java.io.File track = ShayaDocs.findTrackReadme();
				if (track != null) {
					ShayaOpenMapHandler.openFile(track);
				}
			}
		});

		return area;
	}

	private static String bundleVersion() {
		try {
			if (Activator.getDefault() != null && Activator.getDefault().getBundle() != null) {
				return Activator.getDefault().getBundle().getVersion().toString();
			}
		} catch (Exception ignored) {
		}
		return "?";
	}

	private static String toolchainLine() {
		try {
			java.io.File home = org.myau.shaya.ide.toolchain.ShayaToolchain.getToolchainHome();
			if (home != null) {
				return home.getAbsolutePath();
			}
		} catch (Exception ignored) {
		}
		return "(not found — Preferences → SHAYA)";
	}

	@Override
	protected void createButtonsForButtonBar(Composite parent) {
		createButton(parent, IDialogConstants.OK_ID, IDialogConstants.OK_LABEL, true);
	}

	@Override
	public boolean close() {
		if (portrait != null && !portrait.isDisposed()) {
			portrait.dispose();
			portrait = null;
		}
		return super.close();
	}
}
